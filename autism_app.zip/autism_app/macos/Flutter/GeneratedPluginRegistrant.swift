//
//  Generated file. Do not edit.
//

import FlutterMacOS
import Foundation

import flutter_tts

func RegisterGeneratedPlugins(registry: FlutterPluginRegistry) {
  FlutterTtsPlugin.register(with: registry.registrar(forPlugin: "FlutterTtsPlugin"))
}

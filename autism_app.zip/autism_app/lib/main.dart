import 'package:flutter/material.dart';
import 'package:flutter_tts/flutter_tts.dart';

void main() {
  runApp(AutismApp());
}

class AutismApp extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Autism Communication App',
      home: HomeScreen(),
      debugShowCheckedModeBanner: false,
    );
  }
}

class HomeScreen extends StatefulWidget {
  @override
  _HomeScreenState createState() => _HomeScreenState();
}

class _HomeScreenState extends State<HomeScreen>
    with SingleTickerProviderStateMixin {
  FlutterTts flutterTts = FlutterTts();
  double _scale = 1.0;

  void speak(String text) async {
    await flutterTts.speak(text);
  }

  void animateButton() {
    setState(() {
      _scale = 1.2;
    });
    Future.delayed(Duration(milliseconds: 100), () {
      setState(() {
        _scale = 1.0;
      });
    });
  }

  Widget buildButton(String text, IconData icon) {
    return GestureDetector(
      onTap: () {
        speak(text);
        animateButton();
      },
      child: AnimatedContainer(
        duration: Duration(milliseconds: 100),
        transform: Matrix4.identity()..scale(_scale),
        padding: EdgeInsets.all(16),
        decoration: BoxDecoration(
          color: Colors.blue[200],
          borderRadius: BorderRadius.circular(12),
        ),
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Icon(icon, size: 50, color: Colors.white),
            SizedBox(height: 10),
            Text(text,
                style: TextStyle(fontSize: 18, color: Colors.white),
                textAlign: TextAlign.center),
          ],
        ),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        leading: Icon(Icons.menu),
        title: Text("Username"),
        backgroundColor: Colors.blue[400],
        centerTitle: true,
      ),
      body: Padding(
        padding: EdgeInsets.all(20),
        child: GridView.count(
          crossAxisCount: 2,
          mainAxisSpacing: 20,
          crossAxisSpacing: 20,
          children: [
            buildButton("Water", Icons.local_drink),
            buildButton("Hungry", Icons.restaurant),
            buildButton("Sick", Icons.sick),
            buildButton("Sad", Icons.sentiment_dissatisfied),
          ],
        ),
      ),
      bottomNavigationBar: Padding(
        padding: EdgeInsets.all(10),
        child: GestureDetector(
          onTap: () {
            // Home button feedback
            ScaffoldMessenger.of(context).showSnackBar(
              SnackBar(content: Text("Home tapped!")),
            );
          },
          child: Container(
            height: 60,
            decoration: BoxDecoration(
              color: Colors.green[300],
              borderRadius: BorderRadius.circular(12),
            ),
            child: Icon(Icons.home, color: Colors.white, size: 35),
          ),
        ),
      ),
    );
  }
}
